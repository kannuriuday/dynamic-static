function predict_diabetes()
{
    window.location.replace("https://share.streamlit.io/praneethkanchanakuntla/diabets/main/app.py");
}
function predict_heart()
{
    window.location.replace("https://share.streamlit.io/praneethkanchanakuntla/heartattack/main/app.py")
}
function predict_stroke()
{
    window.location.replace("https://strokediseaseprediction.herokuapp.com/")
}
function book()
{
    window.location.replace("https://www.practo.com/order")
}
function prescribe()
{
   window.location.replace("https://www.apollopharmacy.in/")
}
function com()
{
    let x=document.getElementById("comment").value;
    document.getElementById("output").innerHTML=x+"  "+'Got them please book the doctors Appointment';
}
    